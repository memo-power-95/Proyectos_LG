using System;
using System.Windows;

namespace BackupMaker;

public partial class App : Application
{
    public App()
    {
        // Capturar excepciones no manejadas
        this.DispatcherUnhandledException += (sender, e) =>
        {
            MessageBox.Show(
                $"Error no manejado:\n{e.Exception.Message}\n\n{e.Exception.StackTrace}",
                "Error en la Aplicación",
                MessageBoxButton.OK,
                MessageBoxImage.Error
            );
            e.Handled = false;
        };

        // Capturar excepciones en threads
        AppDomain.CurrentDomain.UnhandledException += (sender, e) =>
        {
            var exception = e.ExceptionObject as Exception;
            MessageBox.Show(
                $"Error crítico:\n{exception?.Message}\n\n{exception?.StackTrace}",
                "Error Crítico",
                MessageBoxButton.OK,
                MessageBoxImage.Error
            );
        };
    }
}
