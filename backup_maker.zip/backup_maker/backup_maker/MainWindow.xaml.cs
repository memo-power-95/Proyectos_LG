using System;
using System.IO;
using System.Windows;
using System.Windows.Forms;
using BackupMaker.Models;
using BackupMaker.Services;

namespace BackupMaker;

public partial class MainWindow : Window
{
    private readonly BackupService _backupService;

    public MainWindow()
    {
        InitializeComponent();
        _backupService = new BackupService();
        _backupService.ProgressChanged += OnProgressChanged;
    }

    private void OnProgressChanged(ProgressInfo progressInfo)
    {
        // Actualizar en el hilo de UI
        Dispatcher.Invoke(() =>
        {
            ProgressMessage.Text = progressInfo.Message;
            ProgressBar.Value = progressInfo.ProgressPercentage;
            ProgressPercentageText.Text = $"{progressInfo.ProgressPercentage}%";
        });
    }

    private void BrowseSourceFolder_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new FolderBrowserDialog();
        if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        {
            SourceFolderTextBox.Text = dialog.SelectedPath;
        }
    }

    private void BrowseDestinationFolder_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new FolderBrowserDialog();
        if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        {
            DestinationFolderTextBox.Text = dialog.SelectedPath;
        }
    }

    private void BrowseBackupFile_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Filter = "ZIP Files (*.zip)|*.zip|All Files (*.*)|*.*"
        };
        if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        {
            BackupFileTextBox.Text = dialog.FileName;
        }
    }

    private void BrowseRestoreDestination_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new FolderBrowserDialog();
        if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        {
            RestoreDestinationTextBox.Text = dialog.SelectedPath;
        }
    }

    private async void CreateBackup_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(SourceFolderTextBox.Text))
            {
                MessageBox.Show("Por favor, selecciona una carpeta de origen.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(DestinationFolderTextBox.Text))
            {
                MessageBox.Show("Por favor, selecciona una carpeta de destino.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            CreateBackupButton.IsEnabled = false;
            ProgressBar.Value = 0;

            var backupName = string.IsNullOrWhiteSpace(BackupNameTextBox.Text) 
                ? null 
                : BackupNameTextBox.Text;

            var result = await _backupService.CreateBackupAsync(
                SourceFolderTextBox.Text,
                DestinationFolderTextBox.Text,
                backupName);

            MessageBox.Show(
                $"Backup completado exitosamente.\n\nArchivo: {result.BackupFilePath}\nTamaño: {FormatBytes(result.SizeInBytes)}",
                "Éxito",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            BackupNameTextBox.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error al crear el backup: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            ProgressMessage.Text = "Error durante el backup";
        }
        finally
        {
            CreateBackupButton.IsEnabled = true;
        }
    }

    private async void RestoreBackup_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(BackupFileTextBox.Text))
            {
                MessageBox.Show("Por favor, selecciona un archivo de backup.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(RestoreDestinationTextBox.Text))
            {
                MessageBox.Show("Por favor, selecciona una carpeta de destino.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            RestoreBackupButton.IsEnabled = false;
            ProgressBar.Value = 0;

            await _backupService.RestoreBackupAsync(
                BackupFileTextBox.Text,
                RestoreDestinationTextBox.Text);

            MessageBox.Show(
                "Backup restaurado exitosamente.",
                "Éxito",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            BackupFileTextBox.Clear();
            RestoreDestinationTextBox.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error al restaurar el backup: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            ProgressMessage.Text = "Error durante la restauración";
        }
        finally
        {
            RestoreBackupButton.IsEnabled = false;
        }
    }

    private string FormatBytes(long bytes)
    {
        string[] sizes = { "B", "KB", "MB", "GB" };
        double len = bytes;
        int order = 0;
        while (len >= 1024 && order < sizes.Length - 1)
        {
            order++;
            len = len / 1024;
        }
        return $"{len:F2} {sizes[order]}";
    }
}
