namespace BackupMaker.Models;

public class BackupRecord
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public DateTime CreatedDate { get; set; } = DateTime.Now;
    public string SourceFolderPath { get; set; } = string.Empty;
    public string BackupFilePath { get; set; } = string.Empty;
    public long SizeInBytes { get; set; }
    public string SourceFolderName { get; set; } = string.Empty;

    public string SizeDisplay => FormatSize(SizeInBytes);

    private static string FormatSize(long bytes)
    {
        string[] sizes = { "B", "KB", "MB", "GB" };
        double len = bytes;
        int order = 0;

        while (len >= 1024 && order < sizes.Length - 1)
        {
            order++;
            len = len / 1024;
        }

        return $"{len:0.##} {sizes[order]}";
    }
}
