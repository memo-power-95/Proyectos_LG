namespace BackupMaker.Models;

public class ProgressInfo
{
    public string Message { get; set; } = string.Empty;
    public int ProgressPercentage { get; set; }
}
