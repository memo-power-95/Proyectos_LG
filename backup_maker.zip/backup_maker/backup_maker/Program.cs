﻿namespace BackupMaker;

// WPF auto-generates Main in App.g.cs, so we don't need to define it here

