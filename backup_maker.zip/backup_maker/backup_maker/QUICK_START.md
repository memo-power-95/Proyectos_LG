# 🎯 GUÍA RÁPIDA DE INICIO - BackupMaker

## ✅ Problema Solucionado
**Problema**: La aplicación no mostraba interfaz gráfica al ejecutarse
**Causa**: Faltaba `StartupUri="MainWindow.xaml"` en `App.xaml`
**Solución**: Agregado StartupUri y captura de excepciones mejorada

---

## 🚀 CÓMO EJECUTAR LA APLICACIÓN

### Opción 1: Script Automático (Recomendado)
```powershell
# Haz doble clic en: run.bat
# O ejecuta desde PowerShell:
.\run.ps1
```

### Opción 2: Desde Visual Studio
1. Abre `backup_maker.slnx`
2. Presiona `F5`
3. ¡Listo! La interfaz aparecerá 🎉

### Opción 3: Desde Terminal
```powershell
cd backup_maker
dotnet run
```

### Opción 4: Ejecutable Compilado
```powershell
.\bin\Debug\net10.0-windows\backup_maker.exe
```

---

## 👀 QUÉ DEBERÍAS VER

Cuando ejecutes la aplicación verás una ventana con:

### Sección Superior: "Crear Nuevo Respaldo"
- Campo: "Carpeta a Respaldar:" con botón "Seleccionar..."
- Campo: "Carpeta de Destino:" con botón "Seleccionar..."
- Botón azul: "Crear Respaldo Ahora"

### Sección Inferior: "Historial de Respaldos"
- **Tabla** con columnas:
  - Nombre
  - Fecha de Creación
  - Tamaño
  - Ruta del Respaldo

### Botones de Control:
- 🟠 **Restaurar** - Descomprimir un backup
- 🔵 **Exportar** - Copiar backup a USB/nube
- 🟣 **Importar Backup** - Agregar backup externo
- 🔴 **Eliminar** - Borrar un backup
- 🟣 **Actualizar** - Recargar listado

---

## 🧪 PRUEBA RÁPIDA

1. **Crear un respaldo**:
   - Clic "Seleccionar..." (Carpeta a Respaldar)
   - Elige una carpeta pequeña (Ej: Documentos)
   - Clic "Seleccionar..." (Carpeta de Destino)
   - Elige el Escritorio
   - Clic "Crear Respaldo Ahora"
   - ✅ Verás el backup en la tabla

2. **Exportar el backup**:
   - Selecciona el backup de la tabla
   - Clic "Exportar"
   - Elige una ubicación
   - ✅ Se copiará el ZIP

3. **Importar desde otra ubicación**:
   - Clic "Importar Backup"
   - Selecciona el ZIP exportado
   - Elige ubicación de destino
   - ✅ Se agrega automáticamente al historial

---

## 🔧 SI NO FUNCIONA

### ❌ "No aparece la ventana"
✅ Solución: Abre una terminal y ejecuta:
```powershell
cd C:\Users\elpro\source\repos\backup_maker\backup_maker
dotnet run
```
Esto te mostrará cualquier error en la consola.

### ❌ ".NET 10 no encontrado"
✅ Solución: Descarga desde https://dotnet.microsoft.com/download/dotnet/10.0

### ❌ "Puerto 5000 en uso"
✅ Solución: Es normal en WPF, la aplicación usa GUI no web.

### ❌ Archivos bloqueados al compilar
✅ Solución: Ejecuta:
```powershell
taskkill /F /IM backup_maker.exe
dotnet build
```

---

## 📱 CARACTERÍSTICAS QUE AHORA FUNCIONA

✅ Crear backups ZIP de carpetas completas
✅ Registrar todos los backups en historial
✅ Visualizar backups en tabla interactiva
✅ Restaurar backups a cualquier ubicación
✅ **NUEVO**: Exportar backups a USB/nube
✅ **NUEVO**: Importar backups externos
✅ Eliminar backups del historial
✅ Captura y muestra de errores

---

## 📁 ARCHIVOS IMPORTANTES

```
backup_maker/
├── App.xaml ..................... ✅ Con StartupUri="MainWindow.xaml"
├── App.xaml.cs .................. ✅ Con manejo de excepciones
├── MainWindow.xaml .............. ✅ Interfaz gráfica
├── MainWindow.xaml.cs ........... ✅ Lógica de eventos
├── run.bat ....................... 🆕 Script automático
├── run.ps1 ....................... 🆕 Script PowerShell
├── README.md ..................... 🆕 Documentación completa
└── QUICK_START.md ............... 🆕 Este archivo
```

---

## 🎉 ¡YA ESTÁ LISTO!

Tu aplicación BackupMaker está completamente funcional con interfaz gráfica.

**Próximos pasos opcionales:**
- Crear acceso directo en el escritorio
- Agregar icono personalizado
- Programar backups automáticos
- Agregar encriptación

---

¿Necesitas ayuda? Revisa el README.md para documentación más detallada.
