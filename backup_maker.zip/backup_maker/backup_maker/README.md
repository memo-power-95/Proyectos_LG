# 🔐 BackupMaker - Gestor de Respaldos para Máquinas Embebidas

## 📋 Descripción
Aplicación WPF en .NET 10 para gestionar backups de carpetas con compresión ZIP, registro persistente de historial y opciones de exportación/importación.

---

## 🚀 Cómo Usar

### 1️⃣ **Compilar la Aplicación**
```powershell
cd backup_maker
dotnet build
```

### 2️⃣ **Ejecutar la Aplicación**

**Opción A: Desde Visual Studio**
- Abre `backup_maker.slnx` en Visual Studio
- Presiona `F5` para ejecutar

**Opción B: Desde Terminal**
```powershell
cd backup_maker
dotnet run
```

**Opción C: Ejecutable Compilado**
```powershell
.\bin\Debug\net10.0-windows\backup_maker.exe
```

---

## ✨ Características Principales

### 📦 Crear Respaldo
1. Selecciona la carpeta que deseas respaldar
2. Elige dónde guardar el respaldo
3. Presiona "Crear Respaldo Ahora"
4. El archivo se comprime automáticamente en `.zip`

### 📋 Historial de Respaldos
- Vista de todos los respaldos creados
- Muestra: nombre, fecha, tamaño, ubicación
- Se guardan automáticamente en `AppData\BackupMaker\`

### 🔄 Restaurar
1. Selecciona un respaldo de la lista
2. Presiona "Restaurar"
3. Elige dónde descomprimir los archivos
4. Listo ✅

### 💾 Exportar (Nuevo)
1. Selecciona un respaldo
2. Presiona "Exportar"
3. Copia el archivo ZIP a USB, nube, etc.
4. Sin descomprimir 🎯

### 📥 Importar (Nuevo)
1. Presiona "Importar Backup"
2. Selecciona un archivo `.zip` desde cualquier ubicación
3. Elige dónde guardar la copia
4. Se registra automáticamente en el historial
5. Listo para restaurar 🎉

### 🗑️ Eliminar
- Selecciona un respaldo y presiona "Eliminar"
- Se pide confirmación antes de borrar

### 🔄 Actualizar
- Presiona "Actualizar" para recargar el listado

---

## 📂 Estructura del Proyecto

```
backup_maker/
├── Models/
│   └── BackupRecord.cs          # Modelo de registro de backup
├── Services/
│   ├── BackupService.cs         # Lógica de compresión/restauración
│   └── BackupRegistry.cs        # Gestión del historial (JSON)
├── App.xaml / App.xaml.cs       # Configuración WPF
├── MainWindow.xaml / .cs        # Interfaz y lógica principal
├── Program.cs                   # Entrada de la aplicación
└── backup_maker.csproj          # Configuración del proyecto
```

---

## 💡 Casos de Uso para Máquinas Embebidas

### ✅ Guardar Backup en USB
1. Crea un backup normalmente
2. Presiona "Exportar"
3. Selecciona tu USB
4. El archivo ZIP se copia sin descomprimir

### ✅ Restaurar desde USB (Otra Máquina)
1. Presiona "Importar Backup"
2. Selecciona el archivo del USB
3. Se agrega automáticamente al historial
4. Presiona "Restaurar" cuando necesites

### ✅ Sincronizar Entre Máquinas
1. Máquina A: Exporta a USB
2. Máquina B: Importa desde USB
3. Máquina B: Restaura donde sea necesario

---

## 🛠️ Requisitos

- **.NET 10** o superior
- **Windows 10/11** (o versiones posteriores)
- **Visual Studio 2026** (Community Edition compatible)

---

## 📦 Dependencias NuGet

```xml
<PackageReference Include="System.IO.Compression" Version="4.3.0" />
<PackageReference Include="System.IO.Compression.ZipFile" Version="4.3.0" />
<PackageReference Include="System.Windows.Forms" Version="4.0.0" />
```

---

## 🎨 Interfaz de Usuario

### Colores de Botones
- 🟢 **Verde** (#4CAF50): Seleccionar carpetas
- 🔵 **Azul** (#2196F3): Crear respaldo
- 🟠 **Naranja** (#FF9800): Restaurar
- 🔵 **Teal** (#009688): Exportar
- 🟣 **Morado** (#673AB7): Importar
- 🔴 **Rojo** (#F44336): Eliminar
- 🟣 **Púrpura** (#9C27B0): Actualizar

---

## 🐛 Solución de Problemas

### La aplicación no muestra interfaz
✅ **RESUELTO**: Hemos agregado `StartupUri="MainWindow.xaml"` en App.xaml

### Errores no controlados
✅ **RESUELTO**: App.xaml.cs ahora captura y muestra excepciones

### Archivos bloqueados al compilar
✅ **RESUELTO**: Cierra instancias previas con `taskkill /F /IM backup_maker.exe`

---

## 📝 Notas de Seguridad

- El registro de backups se guarda en `%APPDATA%\BackupMaker\backups_registry.json`
- Considera hacer backup del archivo de registro si es crítico
- Los archivos ZIP no están encriptados (agregar en futuras versiones)

---

## 🚀 Mejoras Futuras

- [ ] Encriptación de backups
- [ ] Backups incrementales
- [ ] Programación automática de backups
- [ ] Sincronización con almacenamiento en nube
- [ ] Soporte para diferentes formatos de compresión

---

## 📄 Licencia

Este proyecto es de código abierto. Úsalo libremente.

---

## 👨‍💻 Autor

Creado para máquinas embebidas con eficiencia en mente.

---

## 📞 Soporte

Si tienes problemas:
1. Verifica que .NET 10 está instalado: `dotnet --version`
2. Limpia compilaciones anteriores: `dotnet clean`
3. Reconstruye: `dotnet build`
4. Ejecuta: `dotnet run`

¡Que disfrutes gestionar tus backups! 🎉
