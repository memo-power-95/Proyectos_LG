using System;
using System.IO;
using System.Text.Json;
using System.Linq;
using System.Collections.Generic;
using BackupMaker.Models;

namespace BackupMaker.Services;

public class BackupRegistry
{
    private readonly string _registryFilePath;
    private List<BackupRecord> _backups = [];

    public BackupRegistry(string? registryPath = null)
    {
        _registryFilePath = registryPath ?? Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "BackupMaker",
            "backups_registry.json"
        );

        Directory.CreateDirectory(Path.GetDirectoryName(_registryFilePath)!);
        Load();
    }

    public IReadOnlyList<BackupRecord> GetAllBackups() => _backups.AsReadOnly();

    public void AddBackup(BackupRecord backup)
    {
        _backups.Add(backup);
        Save();
    }

    public void RemoveBackup(string backupId)
    {
        var backup = _backups.FirstOrDefault(b => b.Id == backupId);
        if (backup != null)
        {
            _backups.Remove(backup);

            // Eliminar el archivo de backup si existe
            if (File.Exists(backup.BackupFilePath))
            {
                try
                {
                    File.Delete(backup.BackupFilePath);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Error al eliminar archivo: {ex.Message}");
                }
            }

            Save();
        }
    }

    public BackupRecord? GetBackup(string backupId) => _backups.FirstOrDefault(b => b.Id == backupId);

    private void Save()
    {
        try
        {
            var json = JsonSerializer.Serialize(_backups, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_registryFilePath, json);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Error guardando registro: {ex.Message}");
        }
    }

    private void Load()
    {
        try
        {
            if (File.Exists(_registryFilePath))
            {
                var json = File.ReadAllText(_registryFilePath);
                _backups = JsonSerializer.Deserialize<List<BackupRecord>>(json) ?? [];
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Error cargando registro: {ex.Message}");
            _backups = [];
        }
    }
}
