using System;
using System.IO;
using System.IO.Compression;
using System.Collections.Generic;
using System.Threading.Tasks;
using BackupMaker.Models;

namespace BackupMaker.Services;

public class BackupService
{
    public event Action<ProgressInfo>? ProgressChanged;

    private int _totalFiles;
    private int _processedFiles;

    public async Task<BackupRecord> CreateBackupAsync(
        string sourceFolder,
        string destinationFolder,
        string? backupName = null)
    {
        if (!Directory.Exists(sourceFolder))
            throw new DirectoryNotFoundException($"La carpeta de origen no existe: {sourceFolder}");

        if (!Directory.Exists(destinationFolder))
            Directory.CreateDirectory(destinationFolder);

        if (!HasWritePermission(destinationFolder))
            throw new UnauthorizedAccessException($"No hay permisos de escritura en la carpeta de destino: {destinationFolder}");

        backupName ??= Path.GetFileName(sourceFolder);
        var timestamp = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
        var zipFileName = $"{backupName}_{timestamp}.zip";
        var zipFilePath = Path.Combine(destinationFolder, zipFileName);

        ProgressChanged?.Invoke(new ProgressInfo { Message = $"Iniciando backup de: {sourceFolder}", ProgressPercentage = 0 });

        return await Task.Run(() =>
        {
            // Contar total de archivos
            _totalFiles = CountFiles(sourceFolder);
            _processedFiles = 0;

            using var archive = ZipFile.Open(zipFilePath, ZipArchiveMode.Create);
            CompressDirectory(archive, sourceFolder, "", sourceFolder);

            ProgressChanged?.Invoke(new ProgressInfo { Message = "Backup completado", ProgressPercentage = 100 });

            var fileInfo = new FileInfo(zipFilePath);
            return new BackupRecord
            {
                SourceFolderPath = sourceFolder,
                BackupFilePath = zipFilePath,
                SizeInBytes = fileInfo.Length,
                SourceFolderName = backupName,
                CreatedDate = DateTime.Now
            };
        });
    }

    public async Task RestoreBackupAsync(string zipFilePath, string destinationFolder)
    {
        if (!File.Exists(zipFilePath))
            throw new FileNotFoundException($"El archivo de backup no existe: {zipFilePath}");

        if (!Directory.Exists(destinationFolder))
            Directory.CreateDirectory(destinationFolder);

        ProgressChanged?.Invoke(new ProgressInfo { Message = "Iniciando restauración...", ProgressPercentage = 0 });

        await Task.Run(() =>
        {
            using var archive = ZipFile.OpenRead(zipFilePath);
            _totalFiles = archive.Entries.Count;
            _processedFiles = 0;

            foreach (var entry in archive.Entries)
            {
                var destinationPath = Path.Combine(destinationFolder, entry.FullName);

                if (string.IsNullOrEmpty(entry.Name))
                {
                    Directory.CreateDirectory(destinationPath);
                }
                else
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(destinationPath)!);
                    entry.ExtractToFile(destinationPath, true);
                }

                _processedFiles++;
                var percentage = (int)((_processedFiles / (double)_totalFiles) * 100);
                ProgressChanged?.Invoke(new ProgressInfo 
                { 
                    Message = $"Restaurando: {entry.Name}", 
                    ProgressPercentage = percentage 
                });
            }
        });

        ProgressChanged?.Invoke(new ProgressInfo { Message = "Restauración completada", ProgressPercentage = 100 });
    }

    private bool HasWritePermission(string folderPath)
    {
        try
        {
            var testFile = Path.Combine(folderPath, ".write_test");
            File.WriteAllText(testFile, "test");
            File.Delete(testFile);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private void CompressDirectory(
        ZipArchive archive,
        string sourceDir,
        string entryPrefix,
        string baseFolder)
    {
        var entries = Directory.GetFileSystemEntries(sourceDir);

        foreach (var entry in entries)
        {
            var fileName = Path.GetFileName(entry);
            var entryPath = string.IsNullOrEmpty(entryPrefix) ? fileName : $"{entryPrefix}/{fileName}";

            if (Directory.Exists(entry))
            {
                CompressDirectory(archive, entry, entryPath, baseFolder);
            }
            else
            {
                try
                {
                    archive.CreateEntryFromFile(entry, entryPath, CompressionLevel.Optimal);
                    _processedFiles++;
                    var percentage = _totalFiles > 0 ? (int)((_processedFiles / (double)_totalFiles) * 100) : 0;
                    ProgressChanged?.Invoke(new ProgressInfo 
                    { 
                        Message = $"Comprimiendo: {entry}", 
                        ProgressPercentage = percentage 
                    });
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Error comprimiendo {entry}: {ex.Message}");
                }
            }
        }
    }

    private int CountFiles(string folderPath)
    {
        int count = 0;
        try
        {
            var entries = Directory.GetFileSystemEntries(folderPath);
            foreach (var entry in entries)
            {
                if (Directory.Exists(entry))
                    count += CountFiles(entry);
                else
                    count++;
            }
        }
        catch { }
        return count;
    }
}
