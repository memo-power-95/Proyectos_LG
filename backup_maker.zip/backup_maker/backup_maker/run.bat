@echo off
REM Script para ejecutar BackupMaker
REM Este archivo permite ejecutar la aplicación haciendo doble clic

cd /d "%~dp0"

REM Verificar si existe el ejecutable compilado
if exist "bin\Debug\net10.0-windows\backup_maker.exe" (
	echo Iniciando BackupMaker...
	start "" "bin\Debug\net10.0-windows\backup_maker.exe"
) else (
	echo El ejecutable no encontrado. Compilando primero...
	dotnet build
	if %ERRORLEVEL% EQU 0 (
		echo Iniciar BackupMaker...
		start "" "bin\Debug\net10.0-windows\backup_maker.exe"
	) else (
		echo Error al compilar. Por favor, verifica tu instalación de .NET 10.
		pause
	)
)
