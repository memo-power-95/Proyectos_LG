# Script para ejecutar BackupMaker
# Uso: .\run.ps1

$scriptPath = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
Set-Location $scriptPath

Write-Host "================================" -ForegroundColor Cyan
Write-Host "  BackupMaker - Gestor de Respaldos" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# Verificar .NET 10
Write-Host "Verificando .NET 10..." -ForegroundColor Yellow
$dotnetVersion = dotnet --version
Write-Host "Versión .NET detectada: $dotnetVersion" -ForegroundColor Green

# Verificar si el ejecutable existe
$exePath = "bin\Debug\net10.0-windows\backup_maker.exe"

if (Test-Path $exePath) {
	Write-Host "Ejecutable encontrado. Iniciando aplicación..." -ForegroundColor Green
	Write-Host ""
	& $exePath
} else {
	Write-Host "Ejecutable no encontrado. Compilando proyecto..." -ForegroundColor Yellow
	Write-Host ""

	# Compilar
	dotnet build

	if ($LASTEXITCODE -eq 0) {
		Write-Host ""
		Write-Host "Compilación exitosa. Iniciando aplicación..." -ForegroundColor Green
		Write-Host ""
		& $exePath
	} else {
		Write-Host ""
		Write-Host "Error al compilar el proyecto." -ForegroundColor Red
		Write-Host "Por favor verifica que .NET 10 está instalado correctamente." -ForegroundColor Red
		Read-Host "Presiona Enter para salir"
	}
}
